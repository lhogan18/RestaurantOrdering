package com.example.restaurantordering.CurrentUser;

import com.example.restaurantordering.Model.User;

public class Current {
    public static User currentUser;
}
